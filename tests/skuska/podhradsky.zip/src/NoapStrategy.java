public class NoapStrategy implements Strategy {
    @Override
    public Double calcExp(double x) {
        return null;
    }

    @Override
    public Double calcSin(double x) {
        return null;
    }
}
